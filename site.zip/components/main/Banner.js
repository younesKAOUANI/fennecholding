import React from 'react'

export default function Banner({title}) {
  return (
    <div className='section !pt-12 !pb-2 overflow-hidden'>
      <h1 className='md:text-7xl text-5xl font-extrabold uppercase text-black font-cobe text-center md:text-left' data-aos='fade-right'>{title}</h1>
    </div>
  )
}
